N'oubliez de modifier dans le code l'emplacement du fichier.
 
Pour ma part c'est : C:\\Users\\nicor\\Desktop\\Projet\\image\\
faites Ctrl H pour remplacer automatiquement en appuyant ensuite sur "Replace All" !

Sinon l'interface ne va pas lire les images.